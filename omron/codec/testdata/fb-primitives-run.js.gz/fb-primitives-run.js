const request = {"binary":"C:\\Program Files (x86)\\OMRON\\CX-One\\CX-Programmer\\CX-Pdata.dll","compilerSHA256":"a32ada50d87bc39697ca7c57337b8e64b14e59bca54d54791929cbe7db678141","requestSHA256":"fc095ebef8ffbb188fea4fc41187d8e3fc91cf346274def4815c2912ae8f4e59","timerCounterMode":"library-default","profiles":[{"cpu":"CPU21","device":"CJ1M"},{"cpu":"CPU65","device":"CJ1H-H"}],"cases":[{"id":"fb-primitive-0","mnemonic":"FBIN","operands":[]},{"id":"fb-primitive-1","mnemonic":"FBIN","operands":["0"]},{"id":"fb-primitive-2","mnemonic":"FBIN","operands":["&0"]},{"id":"fb-primitive-3","mnemonic":"FBIN","operands":["&3"]},{"id":"fb-primitive-4","mnemonic":"FBIN","operands":["&1024"]},{"id":"fb-primitive-5","mnemonic":"FBIN","operands":["#0400"]},{"id":"fb-primitive-6","mnemonic":"FBIN","operands":["&65535"]},{"id":"fb-primitive-7","mnemonic":"FBIN","operands":["&65536"]},{"id":"fb-primitive-8","mnemonic":"FBIN","operands":["&0","&1024"]},{"id":"fb-primitive-9","mnemonic":"FBIN","operands":["&0","&1024","&0"]},{"id":"fb-primitive-10","mnemonic":"FBIRET","operands":[]},{"id":"fb-primitive-11","mnemonic":"FBIRET","operands":["0"]},{"id":"fb-primitive-12","mnemonic":"FBIRET","operands":["&0"]},{"id":"fb-primitive-13","mnemonic":"FBIRET","operands":["&3"]},{"id":"fb-primitive-14","mnemonic":"FBIRET","operands":["&1024"]},{"id":"fb-primitive-15","mnemonic":"FBIRET","operands":["#0400"]},{"id":"fb-primitive-16","mnemonic":"FBIRET","operands":["&65535"]},{"id":"fb-primitive-17","mnemonic":"FBIRET","operands":["&65536"]},{"id":"fb-primitive-18","mnemonic":"FBIRET","operands":["&0","&1024"]},{"id":"fb-primitive-19","mnemonic":"FBIRET","operands":["&0","&1024","&0"]},{"id":"fb-primitive-20","mnemonic":"FBBN","operands":[]},{"id":"fb-primitive-21","mnemonic":"FBBN","operands":["0"]},{"id":"fb-primitive-22","mnemonic":"FBBN","operands":["&0"]},{"id":"fb-primitive-23","mnemonic":"FBBN","operands":["&3"]},{"id":"fb-primitive-24","mnemonic":"FBBN","operands":["&1024"]},{"id":"fb-primitive-25","mnemonic":"FBBN","operands":["#0400"]},{"id":"fb-primitive-26","mnemonic":"FBBN","operands":["&65535"]},{"id":"fb-primitive-27","mnemonic":"FBBN","operands":["&65536"]},{"id":"fb-primitive-28","mnemonic":"FBBN","operands":["&0","&1024"]},{"id":"fb-primitive-29","mnemonic":"FBBN","operands":["&0","&1024","&0"]},{"id":"fb-primitive-30","mnemonic":"FBBRET","operands":[]},{"id":"fb-primitive-31","mnemonic":"FBBRET","operands":["0"]},{"id":"fb-primitive-32","mnemonic":"FBBRET","operands":["&0"]},{"id":"fb-primitive-33","mnemonic":"FBBRET","operands":["&3"]},{"id":"fb-primitive-34","mnemonic":"FBBRET","operands":["&1024"]},{"id":"fb-primitive-35","mnemonic":"FBBRET","operands":["#0400"]},{"id":"fb-primitive-36","mnemonic":"FBBRET","operands":["&65535"]},{"id":"fb-primitive-37","mnemonic":"FBBRET","operands":["&65536"]},{"id":"fb-primitive-38","mnemonic":"FBBRET","operands":["&0","&1024"]},{"id":"fb-primitive-39","mnemonic":"FBBRET","operands":["&0","&1024","&0"]},{"id":"fb-primitive-40","mnemonic":"FBBCALL","operands":[]},{"id":"fb-primitive-41","mnemonic":"FBBCALL","operands":["0"]},{"id":"fb-primitive-42","mnemonic":"FBBCALL","operands":["&0"]},{"id":"fb-primitive-43","mnemonic":"FBBCALL","operands":["&3"]},{"id":"fb-primitive-44","mnemonic":"FBBCALL","operands":["&1024"]},{"id":"fb-primitive-45","mnemonic":"FBBCALL","operands":["#0400"]},{"id":"fb-primitive-46","mnemonic":"FBBCALL","operands":["&65535"]},{"id":"fb-primitive-47","mnemonic":"FBBCALL","operands":["&65536"]},{"id":"fb-primitive-48","mnemonic":"FBBCALL","operands":["&0","&1024"]},{"id":"fb-primitive-49","mnemonic":"FBBCALL","operands":["&0","&1024","&0"]},{"id":"fb-primitive-50","mnemonic":"FBICALL","operands":[]},{"id":"fb-primitive-51","mnemonic":"FBICALL","operands":["0"]},{"id":"fb-primitive-52","mnemonic":"FBICALL","operands":["&0"]},{"id":"fb-primitive-53","mnemonic":"FBICALL","operands":["&3"]},{"id":"fb-primitive-54","mnemonic":"FBICALL","operands":["&1024"]},{"id":"fb-primitive-55","mnemonic":"FBICALL","operands":["#0400"]},{"id":"fb-primitive-56","mnemonic":"FBICALL","operands":["&65535"]},{"id":"fb-primitive-57","mnemonic":"FBICALL","operands":["&65536"]},{"id":"fb-primitive-58","mnemonic":"FBICALL","operands":["&0","&1024"]},{"id":"fb-primitive-59","mnemonic":"FBICALL","operands":["&0","&1024","&0"]},{"id":"fb-primitive-60","mnemonic":"FBCALL","operands":[]},{"id":"fb-primitive-61","mnemonic":"FBCALL","operands":["0"]},{"id":"fb-primitive-62","mnemonic":"FBCALL","operands":["&0"]},{"id":"fb-primitive-63","mnemonic":"FBCALL","operands":["&3"]},{"id":"fb-primitive-64","mnemonic":"FBCALL","operands":["&1024"]},{"id":"fb-primitive-65","mnemonic":"FBCALL","operands":["#0400"]},{"id":"fb-primitive-66","mnemonic":"FBCALL","operands":["&65535"]},{"id":"fb-primitive-67","mnemonic":"FBCALL","operands":["&65536"]},{"id":"fb-primitive-68","mnemonic":"FBCALL","operands":["&0","&1024"]},{"id":"fb-primitive-69","mnemonic":"FBCALL","operands":["&0","&1024","&0"]},{"id":"fb-primitive-70","mnemonic":"FBEND","operands":[]},{"id":"fb-primitive-71","mnemonic":"FBEND","operands":["0"]},{"id":"fb-primitive-72","mnemonic":"FBEND","operands":["&0"]},{"id":"fb-primitive-73","mnemonic":"FBEND","operands":["&3"]},{"id":"fb-primitive-74","mnemonic":"FBEND","operands":["&1024"]},{"id":"fb-primitive-75","mnemonic":"FBEND","operands":["#0400"]},{"id":"fb-primitive-76","mnemonic":"FBEND","operands":["&65535"]},{"id":"fb-primitive-77","mnemonic":"FBEND","operands":["&65536"]},{"id":"fb-primitive-78","mnemonic":"FBEND","operands":["&0","&1024"]},{"id":"fb-primitive-79","mnemonic":"FBEND","operands":["&0","&1024","&0"]},{"id":"fb-primitive-80","mnemonic":"FBBEGIN","operands":[]},{"id":"fb-primitive-81","mnemonic":"FBBEGIN","operands":["0"]},{"id":"fb-primitive-82","mnemonic":"FBBEGIN","operands":["&0"]},{"id":"fb-primitive-83","mnemonic":"FBBEGIN","operands":["&3"]},{"id":"fb-primitive-84","mnemonic":"FBBEGIN","operands":["&1024"]},{"id":"fb-primitive-85","mnemonic":"FBBEGIN","operands":["#0400"]},{"id":"fb-primitive-86","mnemonic":"FBBEGIN","operands":["&65535"]},{"id":"fb-primitive-87","mnemonic":"FBBEGIN","operands":["&65536"]},{"id":"fb-primitive-88","mnemonic":"FBBEGIN","operands":["&0","&1024"]},{"id":"fb-primitive-89","mnemonic":"FBBEGIN","operands":["&0","&1024","&0"]},{"id":"fb-primitive-90","mnemonic":"FBBEND","operands":[]},{"id":"fb-primitive-91","mnemonic":"FBBEND","operands":["0"]},{"id":"fb-primitive-92","mnemonic":"FBBEND","operands":["&0"]},{"id":"fb-primitive-93","mnemonic":"FBBEND","operands":["&3"]},{"id":"fb-primitive-94","mnemonic":"FBBEND","operands":["&1024"]},{"id":"fb-primitive-95","mnemonic":"FBBEND","operands":["#0400"]},{"id":"fb-primitive-96","mnemonic":"FBBEND","operands":["&65535"]},{"id":"fb-primitive-97","mnemonic":"FBBEND","operands":["&65536"]},{"id":"fb-primitive-98","mnemonic":"FBBEND","operands":["&0","&1024"]},{"id":"fb-primitive-99","mnemonic":"FBBEND","operands":["&0","&1024","&0"]}]};
'use strict';
// Research-only calls to a hash-pinned library in a disposable worker.
// `request` is prepended as JSON by Invoke-CJ1InstructionOracle.ps1.
let sequence=0;
function emit(kind,fields){console.log('CJ1_INSTRUCTION '+JSON.stringify(Object.assign({schemaVersion:1,kind,sequence:sequence++},fields)));}
function text(address){let value='';for(let i=0;i<256;i++){const n=address.add(i).readU8();if(!n)return value;value+=String.fromCharCode(n);}throw new Error('string bound exceeded');}
setImmediate(()=>{
 try{
  if(Process.arch!=='ia32' || request.cases.length>512)throw new Error('unsupported architecture/case count');
  const library=Module.load(request.binary);
  library.ensureInitialized();
  const native=(rva,result,args,abi='thiscall')=>new NativeFunction(library.base.add(rva),result,args,abi);
  const stringCtor=native(0x24e2de,'pointer',['pointer','pointer']);
  const stringDtor=native(0x24e2a2,'void',['pointer']);
  const initLanguage=native(0x1ba0e1,'void',[],'mscdecl');
  const kbaseCtor=native(0x1b96e5,'pointer',['pointer']);
  const kbaseDtor=native(0x1b9cf0,'void',['pointer']);
  const setPLC=native(0x1ba36d,'int',['pointer','pointer','pointer']);
  const setBCD=native(0x1cf6b3,'void',['pointer']);
  const setBinary=native(0x1cf6cb,'void',['pointer']);
  const isBCD=native(0x125e0,'int',['pointer']);
  const isBinary=native(0x12600,'int',['pointer']);
  const timerMode=request.timerCounterMode || 'library-default';
  if(!['library-default','bcd','binary'].includes(timerMode))throw new Error('unsupported timer mode');
  const instructionCtor=native(0x16a25a,'pointer',['pointer']);
  const instructionDtor=native(0x16a375,'void',['pointer']);
  const initialise=native(0x16a9e0,'int',['pointer','pointer','pointer','int']);
  const operandEncode=native(0x32d70,'uint32',['pointer','pointer','pointer','pointer','int','int']);
  const encode=native(0x16d735,'int',['pointer','pointer']);
  const retained=[];
  function string(value,owned){const object=Memory.alloc(4);const chars=Memory.allocUtf8String(value);retained.push(object,chars);stringCtor(object,chars);owned.push(object);return object;}
  emit('begin',{compilerSHA256:request.compilerSHA256,requestSHA256:request.requestSHA256,fridaVersion:Frida.version,architecture:Process.arch,programType:0,unitVersion:null,timerCounterMode:timerMode,fullProgramCompiled:false});
  initLanguage();
  const kbase=Memory.alloc(0x4000);retained.push(kbase);kbaseCtor(kbase);
  const profileStrings=[];
  let count=0;
  try{
   for(const cpu of request.profiles){
    const selected=setPLC(kbase,string(cpu.device,profileStrings),string(cpu.cpu,profileStrings));
    if(selected!==1)throw new Error('SetPLC failed for '+cpu.device+' '+cpu.cpu);
    if(timerMode==='bcd')setBCD(kbase);
    if(timerMode==='binary')setBinary(kbase);
    const bcd=isBCD(kbase),binary=isBinary(kbase);
    if((bcd!==0 && bcd!==1) || binary!==1-bcd || (timerMode==='bcd' && bcd!==1) || (timerMode==='binary' && binary!==1))throw new Error('timer mode readback mismatch');
    const descriptor=kbase.add(0x2d50).readPointer();
    emit('profile',{device:cpu.device,cpu:cpu.cpu,selector:descriptor.add(0x44).readU32(),familyMaskLow:descriptor.add(0x68).readU32(),familyMaskHigh:descriptor.add(0x6c).readU32(),timerModeBcd:bcd,timerModeBinary:binary});
    for(const test of request.cases){
     const instance=Memory.alloc(0x100);retained.push(instance);instructionCtor(instance);
     const owned=[];
     const result={id:test.id,device:cpu.device,cpu:cpu.cpu,mnemonic:test.mnemonic,operands:test.operands,initialiseResult:null,operandResults:[],normalized:[],encodeResult:null,words:[],accepted:false};
     try{
      result.initialiseResult=initialise(instance,kbase,string(test.mnemonic,owned),0);
      const definition=instance.add(0x2c).readPointer();
      if(result.initialiseResult===1 && !definition.isNull()){
       result.definition=text(definition.add(12).readPointer());
       result.arity=definition.add(0xc0).readU8();
       if(result.arity===test.operands.length){
        for(let index=0;index<test.operands.length;index++){
         const validation=operandEncode(definition,kbase,instance,string(test.operands[index],owned),index,0);
         result.operandResults.push(validation);
         const record=instance.add(0x10).readPointer().add(index*0x30);
         record.writeU32(validation); // Same caller contract as EncodeOperands.
         result.normalized.push({value:record.add(4).readU32(),flags:record.add(8).readU32()});
         if(validation!==0)break;
        }
        if(result.operandResults.length===result.arity && result.operandResults.every(code=>code===0)){
         result.encodeResult=encode(instance,kbase);
         const wordCount=instance.add(0x34).readU8();
         if(wordCount>128)throw new Error('instruction word bound exceeded');
         const buffer=instance.add(0x0c).readPointer();
         for(let i=0;i<wordCount;i++)result.words.push(buffer.add(i*4).readU32());
         result.accepted=result.encodeResult===0 && result.words.length>0;
        }
       }
      }
     }finally{
      instructionDtor(instance);
      for(const object of owned.reverse())stringDtor(object);
     }
     emit('case',result);count++;
    }
   }
  }finally{
   kbaseDtor(kbase);
   for(const object of profileStrings.reverse())stringDtor(object);
  }
  emit('done',{caseCount:count});
 }catch(error){emit('error',{message:String(error),stack:error.stack});}
});
