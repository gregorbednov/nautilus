const request = {"binary":"C:\\Program Files (x86)\\OMRON\\CX-One\\CX-Programmer\\CX-Pdata.dll","compilerSHA256":"a32ada50d87bc39697ca7c57337b8e64b14e59bca54d54791929cbe7db678141","requestSHA256":"4cace9bfd62a27a9b2f08403bc929d489117627fe1b698d4ec40a20910aa484a","timerCounterMode":"library-default","profiles":[{"cpu":"CPU21","device":"CJ1M"},{"cpu":"CPU65","device":"CJ1H-H"}],"cases":[{"id":"compare-0","mnemonic":"CMP(020)","operands":["0","D100"]},{"id":"compare-1","mnemonic":"CMP(020)","operands":["D100","0"]},{"id":"compare-2","mnemonic":"CMP(020)","operands":["6143","D100"]},{"id":"compare-3","mnemonic":"CMP(020)","operands":["D100","6143"]},{"id":"compare-4","mnemonic":"CMP(020)","operands":["6144","D100"]},{"id":"compare-5","mnemonic":"CMP(020)","operands":["D100","6144"]},{"id":"compare-6","mnemonic":"CMP(020)","operands":["W0","D100"]},{"id":"compare-7","mnemonic":"CMP(020)","operands":["D100","W0"]},{"id":"compare-8","mnemonic":"CMP(020)","operands":["W511","D100"]},{"id":"compare-9","mnemonic":"CMP(020)","operands":["D100","W511"]},{"id":"compare-10","mnemonic":"CMP(020)","operands":["W512","D100"]},{"id":"compare-11","mnemonic":"CMP(020)","operands":["D100","W512"]},{"id":"compare-12","mnemonic":"CMP(020)","operands":["H0","D100"]},{"id":"compare-13","mnemonic":"CMP(020)","operands":["D100","H0"]},{"id":"compare-14","mnemonic":"CMP(020)","operands":["H511","D100"]},{"id":"compare-15","mnemonic":"CMP(020)","operands":["D100","H511"]},{"id":"compare-16","mnemonic":"CMP(020)","operands":["H512","D100"]},{"id":"compare-17","mnemonic":"CMP(020)","operands":["D100","H512"]},{"id":"compare-18","mnemonic":"CMP(020)","operands":["A0","D100"]},{"id":"compare-19","mnemonic":"CMP(020)","operands":["D100","A0"]},{"id":"compare-20","mnemonic":"CMP(020)","operands":["A447","D100"]},{"id":"compare-21","mnemonic":"CMP(020)","operands":["D100","A447"]},{"id":"compare-22","mnemonic":"CMP(020)","operands":["A448","D100"]},{"id":"compare-23","mnemonic":"CMP(020)","operands":["D100","A448"]},{"id":"compare-24","mnemonic":"CMP(020)","operands":["A959","D100"]},{"id":"compare-25","mnemonic":"CMP(020)","operands":["D100","A959"]},{"id":"compare-26","mnemonic":"CMP(020)","operands":["A960","D100"]},{"id":"compare-27","mnemonic":"CMP(020)","operands":["D100","A960"]},{"id":"compare-28","mnemonic":"CMP(020)","operands":["D0","D100"]},{"id":"compare-29","mnemonic":"CMP(020)","operands":["D100","D0"]},{"id":"compare-30","mnemonic":"CMP(020)","operands":["D32767","D100"]},{"id":"compare-31","mnemonic":"CMP(020)","operands":["D100","D32767"]},{"id":"compare-32","mnemonic":"CMP(020)","operands":["D32768","D100"]},{"id":"compare-33","mnemonic":"CMP(020)","operands":["D100","D32768"]},{"id":"compare-34","mnemonic":"CMP(020)","operands":["T0","D100"]},{"id":"compare-35","mnemonic":"CMP(020)","operands":["D100","T0"]},{"id":"compare-36","mnemonic":"CMP(020)","operands":["T4095","D100"]},{"id":"compare-37","mnemonic":"CMP(020)","operands":["D100","T4095"]},{"id":"compare-38","mnemonic":"CMP(020)","operands":["T4096","D100"]},{"id":"compare-39","mnemonic":"CMP(020)","operands":["D100","T4096"]},{"id":"compare-40","mnemonic":"CMP(020)","operands":["C0","D100"]},{"id":"compare-41","mnemonic":"CMP(020)","operands":["D100","C0"]},{"id":"compare-42","mnemonic":"CMP(020)","operands":["C4095","D100"]},{"id":"compare-43","mnemonic":"CMP(020)","operands":["D100","C4095"]},{"id":"compare-44","mnemonic":"CMP(020)","operands":["C4096","D100"]},{"id":"compare-45","mnemonic":"CMP(020)","operands":["D100","C4096"]},{"id":"compare-46","mnemonic":"CMP(020)","operands":["#0000","D100"]},{"id":"compare-47","mnemonic":"CMP(020)","operands":["D100","#0000"]},{"id":"compare-48","mnemonic":"CMP(020)","operands":["#FFFF","D100"]},{"id":"compare-49","mnemonic":"CMP(020)","operands":["D100","#FFFF"]},{"id":"compare-50","mnemonic":"CMP(020)","operands":["#DEAD","D100"]},{"id":"compare-51","mnemonic":"CMP(020)","operands":["D100","#DEAD"]},{"id":"compare-52","mnemonic":"CMP(020)","operands":["#10000","D100"]},{"id":"compare-53","mnemonic":"CMP(020)","operands":["D100","#10000"]},{"id":"compare-54","mnemonic":"CMP(020)","operands":["#GGGG","D100"]},{"id":"compare-55","mnemonic":"CMP(020)","operands":["D100","#GGGG"]},{"id":"compare-56","mnemonic":"CMP(020)","operands":["&0","D100"]},{"id":"compare-57","mnemonic":"CMP(020)","operands":["D100","&0"]},{"id":"compare-58","mnemonic":"CMP(020)","operands":["&65535","D100"]},{"id":"compare-59","mnemonic":"CMP(020)","operands":["D100","&65535"]},{"id":"compare-60","mnemonic":"CMP(020)","operands":["&65536","D100"]},{"id":"compare-61","mnemonic":"CMP(020)","operands":["D100","&65536"]},{"id":"compare-62","mnemonic":"CMP(020)","operands":["#-1","D100"]},{"id":"compare-63","mnemonic":"CMP(020)","operands":["D100","#-1"]},{"id":"compare-64","mnemonic":"CMP(020)","operands":["&-1","D100"]},{"id":"compare-65","mnemonic":"CMP(020)","operands":["D100","&-1"]},{"id":"compare-66","mnemonic":"CMP(020)","operands":["&+1","D100"]},{"id":"compare-67","mnemonic":"CMP(020)","operands":["D100","&+1"]},{"id":"compare-68","mnemonic":"CMP(020)","operands":["0.00","D100"]},{"id":"compare-69","mnemonic":"CMP(020)","operands":["D100","0.00"]},{"id":"compare-70","mnemonic":"CMP(020)","operands":["W0.00","D100"]},{"id":"compare-71","mnemonic":"CMP(020)","operands":["D100","W0.00"]},{"id":"compare-72","mnemonic":"CMP(020)","operands":["*D0","D100"]},{"id":"compare-73","mnemonic":"CMP(020)","operands":["D100","*D0"]},{"id":"compare-74","mnemonic":"CMP(020)","operands":["@D0","D100"]},{"id":"compare-75","mnemonic":"CMP(020)","operands":["D100","@D0"]},{"id":"compare-76","mnemonic":"CMP(020)","operands":["IR0","D100"]},{"id":"compare-77","mnemonic":"CMP(020)","operands":["D100","IR0"]},{"id":"compare-78","mnemonic":"CMP(020)","operands":["TR0","D100"]},{"id":"compare-79","mnemonic":"CMP(020)","operands":["D100","TR0"]},{"id":"compare-80","mnemonic":"CMP(020)","operands":["TRUE","D100"]},{"id":"compare-81","mnemonic":"CMP(020)","operands":["D100","TRUE"]},{"id":"compare-82","mnemonic":"CMP","operands":["#DEAD","#DEAD"]},{"id":"compare-83","mnemonic":"CMP","operands":["&65535","#FFFF"]},{"id":"compare-84","mnemonic":"CMP","operands":["D0"]},{"id":"compare-85","mnemonic":"CMP","operands":[]},{"id":"compare-86","mnemonic":"CMP(020)","operands":["#DEAD","#DEAD"]},{"id":"compare-87","mnemonic":"CMP(020)","operands":["&65535","#FFFF"]},{"id":"compare-88","mnemonic":"CMP(020)","operands":["D0"]},{"id":"compare-89","mnemonic":"CMP(020)","operands":[]},{"id":"compare-90","mnemonic":"CMP(20)","operands":["#DEAD","#DEAD"]},{"id":"compare-91","mnemonic":"CMP(20)","operands":["&65535","#FFFF"]},{"id":"compare-92","mnemonic":"CMP(20)","operands":["D0"]},{"id":"compare-93","mnemonic":"CMP(20)","operands":[]},{"id":"compare-94","mnemonic":"CMP(999)","operands":["#DEAD","#DEAD"]},{"id":"compare-95","mnemonic":"CMP(999)","operands":["&65535","#FFFF"]},{"id":"compare-96","mnemonic":"CMP(999)","operands":["D0"]},{"id":"compare-97","mnemonic":"CMP(999)","operands":[]},{"id":"compare-98","mnemonic":"@CMP(020)","operands":["#DEAD","#DEAD"]},{"id":"compare-99","mnemonic":"@CMP(020)","operands":["&65535","#FFFF"]},{"id":"compare-100","mnemonic":"@CMP(020)","operands":["D0"]},{"id":"compare-101","mnemonic":"@CMP(020)","operands":[]},{"id":"compare-102","mnemonic":"%CMP(020)","operands":["#DEAD","#DEAD"]},{"id":"compare-103","mnemonic":"%CMP(020)","operands":["&65535","#FFFF"]},{"id":"compare-104","mnemonic":"%CMP(020)","operands":["D0"]},{"id":"compare-105","mnemonic":"%CMP(020)","operands":[]}]};
'use strict';
// Research-only calls to a hash-pinned library in a disposable worker.
// `request` is prepended as JSON by Invoke-CJ1InstructionOracle.ps1.
let sequence=0;
function emit(kind,fields){console.log('CJ1_INSTRUCTION '+JSON.stringify(Object.assign({schemaVersion:1,kind,sequence:sequence++},fields)));}
function text(address){let value='';for(let i=0;i<256;i++){const n=address.add(i).readU8();if(!n)return value;value+=String.fromCharCode(n);}throw new Error('string bound exceeded');}
setImmediate(()=>{
 try{
  if(Process.arch!=='ia32' || request.cases.length>512)throw new Error('unsupported architecture/case count');
  const library=Module.load(request.binary);
  library.ensureInitialized();
  const native=(rva,result,args,abi='thiscall')=>new NativeFunction(library.base.add(rva),result,args,abi);
  const stringCtor=native(0x24e2de,'pointer',['pointer','pointer']);
  const stringDtor=native(0x24e2a2,'void',['pointer']);
  const initLanguage=native(0x1ba0e1,'void',[],'mscdecl');
  const kbaseCtor=native(0x1b96e5,'pointer',['pointer']);
  const kbaseDtor=native(0x1b9cf0,'void',['pointer']);
  const setPLC=native(0x1ba36d,'int',['pointer','pointer','pointer']);
  const setBCD=native(0x1cf6b3,'void',['pointer']);
  const setBinary=native(0x1cf6cb,'void',['pointer']);
  const isBCD=native(0x125e0,'int',['pointer']);
  const isBinary=native(0x12600,'int',['pointer']);
  const timerMode=request.timerCounterMode || 'library-default';
  if(!['library-default','bcd','binary'].includes(timerMode))throw new Error('unsupported timer mode');
  const instructionCtor=native(0x16a25a,'pointer',['pointer']);
  const instructionDtor=native(0x16a375,'void',['pointer']);
  const initialise=native(0x16a9e0,'int',['pointer','pointer','pointer','int']);
  const operandEncode=native(0x32d70,'uint32',['pointer','pointer','pointer','pointer','int','int']);
  const encode=native(0x16d735,'int',['pointer','pointer']);
  const retained=[];
  function string(value,owned){const object=Memory.alloc(4);const chars=Memory.allocUtf8String(value);retained.push(object,chars);stringCtor(object,chars);owned.push(object);return object;}
  emit('begin',{compilerSHA256:request.compilerSHA256,requestSHA256:request.requestSHA256,fridaVersion:Frida.version,architecture:Process.arch,programType:0,unitVersion:null,timerCounterMode:timerMode,fullProgramCompiled:false});
  initLanguage();
  const kbase=Memory.alloc(0x4000);retained.push(kbase);kbaseCtor(kbase);
  const profileStrings=[];
  let count=0;
  try{
   for(const cpu of request.profiles){
    const selected=setPLC(kbase,string(cpu.device,profileStrings),string(cpu.cpu,profileStrings));
    if(selected!==1)throw new Error('SetPLC failed for '+cpu.device+' '+cpu.cpu);
    if(timerMode==='bcd')setBCD(kbase);
    if(timerMode==='binary')setBinary(kbase);
    const bcd=isBCD(kbase),binary=isBinary(kbase);
    if((bcd!==0 && bcd!==1) || binary!==1-bcd || (timerMode==='bcd' && bcd!==1) || (timerMode==='binary' && binary!==1))throw new Error('timer mode readback mismatch');
    const descriptor=kbase.add(0x2d50).readPointer();
    emit('profile',{device:cpu.device,cpu:cpu.cpu,selector:descriptor.add(0x44).readU32(),familyMaskLow:descriptor.add(0x68).readU32(),familyMaskHigh:descriptor.add(0x6c).readU32(),timerModeBcd:bcd,timerModeBinary:binary});
    for(const test of request.cases){
     const instance=Memory.alloc(0x100);retained.push(instance);instructionCtor(instance);
     const owned=[];
     const result={id:test.id,device:cpu.device,cpu:cpu.cpu,mnemonic:test.mnemonic,operands:test.operands,initialiseResult:null,operandResults:[],normalized:[],encodeResult:null,words:[],accepted:false};
     try{
      result.initialiseResult=initialise(instance,kbase,string(test.mnemonic,owned),0);
      const definition=instance.add(0x2c).readPointer();
      if(result.initialiseResult===1 && !definition.isNull()){
       result.definition=text(definition.add(12).readPointer());
       result.arity=definition.add(0xc0).readU8();
       if(result.arity===test.operands.length){
        for(let index=0;index<test.operands.length;index++){
         const validation=operandEncode(definition,kbase,instance,string(test.operands[index],owned),index,0);
         result.operandResults.push(validation);
         const record=instance.add(0x10).readPointer().add(index*0x30);
         record.writeU32(validation); // Same caller contract as EncodeOperands.
         result.normalized.push({value:record.add(4).readU32(),flags:record.add(8).readU32()});
         if(validation!==0)break;
        }
        if(result.operandResults.length===result.arity && result.operandResults.every(code=>code===0)){
         result.encodeResult=encode(instance,kbase);
         const wordCount=instance.add(0x34).readU8();
         if(wordCount>128)throw new Error('instruction word bound exceeded');
         const buffer=instance.add(0x0c).readPointer();
         for(let i=0;i<wordCount;i++)result.words.push(buffer.add(i*4).readU32());
         result.accepted=result.encodeResult===0 && result.words.length>0;
        }
       }
      }
     }finally{
      instructionDtor(instance);
      for(const object of owned.reverse())stringDtor(object);
     }
     emit('case',result);count++;
    }
   }
  }finally{
   kbaseDtor(kbase);
   for(const object of profileStrings.reverse())stringDtor(object);
  }
  emit('done',{caseCount:count});
 }catch(error){emit('error',{message:String(error),stack:error.stack});}
});
